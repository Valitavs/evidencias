const express = require('express')
const router = express.Router()
const multer = require("multer");
const path = require('path')

const storage = multer.diskStorage({
    destination: (req, file, cb)=>{
        cb(null, './public/uploads')
    },
    filename: (req, file, cb)=> {
        console.log(file)
        cb(null, Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({storage: storage})

const conexion = require('./database/db')



router.get('/',(req,res)=>{
    res.render('inicio')
})

router.get('/Signin',(req,res)=>{
    res.render('signin')
})

router.get('/Restaurante',(req,res)=>{
    res.render('config-res')
})

router.get('/Menu',(req,res)=>{
    conexion.query('SELECT * FROM menu',(error,results)=>{
        if(error){
            throw error
        }else{
            res.render('menu',{results:results})
        }
    })
})

router.get('/delete/:idmenu',(req,res)=>{
    const id = req.params.idmenu
    conexion.query('DELETE FROM menu WHERE idmenu =?', [id], (error,results)=>{
        if(error){
            throw error
        }else{
            res.redirect('/Restaurante')
        }
    })
})

router.get('/edit/:idmenu',(req,res)=>{
    const idmenu = req.params.idmenu
    conexion.query('SELECT * FROM menu WHERE idmenu =?',[idmenu], (error,results)=>{
        if(error){
            throw error
        }else{
            res.render('Edit.ejs',{usuario:results[0]})
        }
    })
})

router.get('/Registro',(req,res)=>{
    res.render('registro')
})

router.get('/Iniciouser',(req,res)=>{
    res.render('inicio-usuario')
})


router.get('/Perfil',(req,res)=>{
    res.render('perfil-usuario')
})

router.get('/Agregar',(req,res)=>{
    res.render('add-menu.ejs')
})

const func = require('./controlers/funciones');
const { error } = require('console');

router.post("/save", func.save)



router.post("/savemenu",upload.single("image"),(req,res)=>{
    const nombre_menu = req.body.nombre_menu
    const descripcion_menu = req.body.descripcion_menu
    const precio_menu = req.body.precio_menu

    conexion.query('INSERT INTO menu SET ?', {nombre_menu:nombre_menu, descripcion_menu:descripcion_menu, precio_menu:precio_menu, fechacreacion:Date.now()}, (error,results)=>{
        if(error){
            console.log(error)
        }else{
            res.redirect('/Restaurante')
        }
    })
})

router.post("/update", upload.single("image"),(req,res)=>{
    const id = req.body.idmenu
    const nombre_menu = req.body.nombre_menu
    const descripcion_menu = req.body.descripcion_menu
    const precio_menu = req.body.precio_menu

    conexion.query('UPDATE menu SET ? WHERE idmenu =?', [{nombre_menu:nombre_menu, descripcion_menu:descripcion_menu, precio_menu:precio_menu, fechacreacion:Date.now()}, id], (error,results)=>{
        if(error){
            console.log(error)
        }else{
            res.redirect('/Restaurante')
        }
    })
})



module.exports = router