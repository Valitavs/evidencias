const express = require('express')
const app = express()

app.use(express.urlencoded({extended:false}))
app.use(express.json())
app.set('view engine', 'ejs')

app.use('/', require('./router'))

app.listen(4000, ()=>{
    console.log('Servidor corriendo en http://localhost:4000')
})

app.use(express.static(__dirname + '/public'));