INSERT INTO Usuarios (idUsuario, Contraseña, Estado_sesion, Fecha_Registro, Correo)VALUES
(1,'yidoxyEiRfwBEDm9FDUR',1,'2023-10-05', 'valentina@example.com'),
(2, 'fiCnckYWcpb8dExA0dW9',0,'2023-10-01', 'isabella@example.com'),
(3,'CLifKUTWN5u1hhcxdr20',1, '2023-10-04', 'luz@example.com'),
(4, '5pYjkXxgwD46wp9eH6py',1, '2023-10-01', 'edison@example.com'),
(5, 'NjwWfDhsj7TvfthpM7MW',0,'2023-10-06', 'yuly@example.com'),
(6,'Z8AZaTt36KcKHvG019fg',0,'2023-10-04', 'wilmer@example.com'),
(7, 'c27GqhT7CuBL27UiRou2',0,'2023-10-04', 'carmen@example.com'),
(8,'L6cfp6wukEgRwNGJF5T3',1,'2023-10-06', 'nestor@example.com'),
(9, 'p9z3sVpPxvKC308Yy4E1',1,'2023-10-08', 'alvaro@example.com'),
(10, 'U4ToGiX63XEv20rHs4w3',0,'2023-10-07', 'emily@example.com');

INSERT INTO Clientes (idCliente, idUsuario, Nombre_cliente, Direccion_cliente, Correo_cliente, Numero_Tarjeta, Nombre_enla_tarjeta, Fecha_caducidad, CVV)VALUES
(1,1,'Valentina Vargas','Caserio Carolina Sosa s/n. - Norfolk, Gal / 78762','valentina@example.com', 4194296186927689, 'Valentina Vargas', '2024-07-01', 582),
(2,2,'Isabella Borda','Municipio Lucas Alfaro, 1 - Clearwater, Cat / 40790','isabella@example.com', 4496467568786051, 'Isabella Borda', '2027-05-21', 170),
(3,3,'Luz Dary Sanchez','Pasaje María Elena Botello s/n. - Concord, Vas / 17033','luz@example.com', 4434826931756858, 'Luz Dary Sanchez', '2025-10-15', 847),
(4,4,'Edison Vargas','Polígono José 3 - Victoria, Rio / 57271','edison@example.com', 4100457784170337, 'Edison Vargas', '2026-05-12', 507),
(5,5,'Yuly Vargas','Ramal Micaela Martínez, 7 - Olathe, Cbr / 38630','yuly@example.com', 403638198387-2536, 'Yuly Vargas', '2024-02-07', 022);

INSERT INTO Restaurantes (idRestaurante, idUsuario, idMenu, Usuario_admin, Nombre_res, Correo_res, Direccion_res)VALUES
(1,6,1,'Wilmer Vargas','Comida Rapida', 'comidaRa@example.com', 'Poblado Cristina, 3 - Anaheim, Mur / 48007'),
(2,7,2, 'Carmen Corredor','Comida Rapida Rey', 'rey@example.com', 'Entrada Santiago, 2 - Westland, Ext / 93325'),
(3,8,3,'Nestor Sanchez', 'Vivo', 'vivo@example.com', 'Manzana David 2 - Round Rock, And / 17349'),
(4,9,4, 'Alvaro Sanchez', 'Catcher', 'catcher@example.com', 'Sector José Emilio 4 - Pico Rivera, Nav / 09346'),
(5,10,5, 'Emily Riaño','Venus Comida', 'venus@example.com', 'Subida Jorge Luis, 1 - Washington, Gal / 16898');

INSERT INTO Pedidos (idPedido, Fecha_creacion, Estado, Cantidad, idCarrito, idProducto)VALUES
(1, '2023-10-10', 'Enviado', 2,5,1),
(2, '2023-10-09', 'Recibido', 1,3,6),
(3, '2023-10-08', 'Recibido', 2,2,7),
(4, '2023-10-10', 'Enviado', 3,4,5),
(5, '2023-10-09', 'Recibido', 5,1,1);

INSERT INTO Info_Envios (idEnvio, Tipo_envio, Costo_envio, Fecha_envio, Hora_envio, idPedido)VALUES
(1, 'Rapido', 10000, '2023-10-09', '1:10', 2),
(2, 'Normal', 5000, '2023-10-10', '2:30', 1),
(3, 'Rapido', 11000, '2023-10-09', '12:00', 5),
(4, 'Normal', 2000, '2023-10-08', '2:15', 3),
(5, 'Normal', 5000, '2023-10-10', '3:10', 4);

INSERT INTO Carrito_de_compras (idCarrito, idCliente)VALUES
(1,1),
(2,2),
(3,5),
(4,3),
(5,4);

INSERT INTO Productos (idProducto, Precio, Nombre_producto, Detalles, idMenu)VALUES
(1,15000,'Perro Caliente','Pan, Salchicha, Salsas',1),
(2,18000,'Choriperro','Pan, Chorizo, Salsas',1),
(3,16000,'Hamburguesa','Pan, Carne, Salsas',2),
(4,20000,'Hamburguesa doble','Pan, Doble carne, Salsas',2),
(5,10000,'Salchipapa','Papas, Salchicha, Salsas',3),
(6,15000,'Salchicriolla','Papas criollas, Salchicha, Salsas',3),
(7,10000,'Waffle','Waffle, Helado, Frutas',4),
(8,15000,'Ensalada de frutas','Frutas, Queso, salsas',4),
(9,13000,'Almuerzo corriente','Arroz, Principio, Carne',5),
(10,16000,'Salchipapa','Arroz, Principio, Carne, Papas',5);

INSERT INTO Menu (idMenu)VALUES
(1),
(2),
(3),
(4),
(5);

INSERT INTO Reservacion (idReserva, Tipo_reserva, idCliente, idReservadia)VALUES
(1,'Cumpleaños',1,1),
(2,'Graduacion',3,5),
(3,'Aniversario',2,4),
(4,'Cumpleaños',4,3),
(5,'Graduacion',5,2);

INSERT INTO Reservacion_dispo (idReservadia, Dias_dispo, Horas_dispo, idRestaurante)VALUES
(1, '2023-10-28', 2,5),
(2, '2023-10-28', 4,2),
(3,  '2023-10-14', 12,3),
(4, '2023-10-13', 8,1),
(5, '2023-10-27', 3,4);