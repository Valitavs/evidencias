const fs = require('fs')
fs.readFile('carros.json', 'utf8', (err,data)=>{
    if(err){
        console.error('Error al leer el archivo JSON', err)
        return
    }
    
    const datos = JSON.parse(data)

    
    datos.Carros[0].Placa[0] = 'WWE687'
    datos.Carros[0].Placa[1] = 'QWA575'
    datos.Carros[0].Tipo = 'Minivan'
    datos.Carros[0].Kilometraje = 15500
    datos.Carros[0].NumeroSerie = 'MK3HBQXEJLE8HYBC'
    datos.Carros[0].Modelo = 'Honda Odyssey'
    datos.Carros[0].Marca = 'Honda'
    
    const datosActualizados = JSON.stringify(datos,null,2)

    
    fs.writeFile('carros.json', datosActualizados, (err)=>{
        if(err){
            console.error('Error al guardar los cambios', err)
            return
        }
        console.log('Cambios guardados con exito')
    })
})