const fs = require('fs')

fs.readFile('carros.json', 'utf8', (err,data)=>{
    if(err){
        console.error('Error al leer el archivo JSON', err)
        return
    }
    const datos = JSON.parse(data)

    console.log(datos.Carros)
})