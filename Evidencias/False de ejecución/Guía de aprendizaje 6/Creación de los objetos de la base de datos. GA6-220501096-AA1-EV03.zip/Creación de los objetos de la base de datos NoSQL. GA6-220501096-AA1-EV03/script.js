const fs = require('fs')
fs.readFile('carros.json', 'utf8', (err,data)=>{
    if(err){
        console.error('Error al leer el archivo JSON', err)
        return
    }
    
    const datos = JSON.parse(data)

    
    datos.Carros[0].Placa.push('ASA874')
    datos.Carros[1].Tipo.push('Sports Car')
    datos.Carros[2].Kilometraje.push('16.000')
    datos.Carros[3].NumeroSerie.push('6LXT34U93YRJLWH3')
    datos.Carros[4].Modelo.push('Renault SANDERO')

    
    const datosActualizados = JSON.stringify(datos,null,2)

    
    fs.writeFile('carros.json', datosActualizados, (err)=>{
        if(err){
            console.error('Error al guardar los cambios', err)
            return
        }
        console.log('Cambios guardados con exito')
    })
})