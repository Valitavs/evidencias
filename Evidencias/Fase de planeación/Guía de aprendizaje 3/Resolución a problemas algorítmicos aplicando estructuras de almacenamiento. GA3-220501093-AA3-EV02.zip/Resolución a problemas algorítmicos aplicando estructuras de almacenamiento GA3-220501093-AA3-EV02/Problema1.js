function perimetroTriangulo(){
    let a = prompt("Ingrese lado a")
    let b = prompt("Ingrese lado b")
    let c = prompt("Ingrese lado c")
    a = Number(a)
    b = Number(b)
    c = Number(c)
    pt = a+b+c
    console.log("El perimetro del triangulo es: ", pt)
}

function perimetroRectangulo(){
    let a = prompt("Ingrese lado a")
    let b = prompt("Ingrese lado b")
    a = Number(a)
    b = Number(b)
    pr = 2*(a+b)
    console.log("El perimetro del rectangulo es: ", pr)
}

function perimetroCuadrado(){
    let a = prompt("Ingrese lado a")
    a = Number(a)
    pc = 4*a
    console.log("El perimetro del cuadrado es: ", pc)
}

function perimetroCirculo(){
    let r = prompt("Ingrese radio: ")
    r = Number(r)
    pci = 2*Math.PI*r**2
    console.log("El perimetro del circulo es: ", pci)
}

function areaTriangulo(){
    let b = prompt("Ingrese base: ")
    let h = prompt("Ingrese altura: ")
    b = Number(b)
    h = Number(h)
    at = (b*h)/2
    console.log("El area del triangulo es: ", at)
}

function areaRectangulo(){
    let a = prompt("Ingrese lado a: ")
    let b = prompt("Ingrese lado b: ")
    a = Number(a)
    b = Number(b)
    arec = b*a
    console.log("El area del rectangulo es: ", arec)
}

function areaCuadrado(){
    let a = prompt("Ingrese lado a: ")
    a = Number(a)
    ac = a**2
    console.log("El area del cuadrado es: ", ac)
}

function areaCirculo(){
    let r = prompt("Ingrese radio: ")
    r = Number(r)
    acir = Math.PI*r**2
    console.log("El area del circulo es: ", acir)
}

do{
    let valor = prompt("1. Sacar Perimetro \n2. Sacar Area","Ingrese numero")
    switch (true){
        case valor == 1:
            let pe = prompt("1. Sacar perimetro de un triangulo\n2. Sacar perimetro de un rectangulo\n3. Sacar perimentro de un cuadrado\n4. Sacar perimetro de un circulo","Ingrese numero")
            switch (true){
                case pe == 1:
                    perimetroTriangulo()
                break
                case pe == 2:
                    perimetroRectangulo()
                break
                case pe == 3:
                    perimetroCuadrado()
                break
                case pe == 4:
                    perimetroCirculo()
                break
                default:
                    console.log("El valor ingresado no es una opción")
            }
        break
        case valor == 2:
            let ar = prompt("1. Sacar area de un triangulo\n2. Sacar area de un rectangulo\n3. Sacar area de un cuadrado\n4. Sacar area de un circulo","Ingrese numero")
            switch (true){
                case ar == 1:
                    areaTriangulo()
                break
                case ar == 2:
                    areaRectangulo()
                break
                case ar == 3:
                    areaCuadrado()
                break
                case ar == 4:
                    areaCirculo()
                break
                default:
                    console.log("El valor ingresado no es una opción")
            }
        break
        default:
            console.log("El valor ingresado no es una opción")
    } 
valor1 =  prompt("1 si quiere volver al principio")
}while(valor1 == "1")
