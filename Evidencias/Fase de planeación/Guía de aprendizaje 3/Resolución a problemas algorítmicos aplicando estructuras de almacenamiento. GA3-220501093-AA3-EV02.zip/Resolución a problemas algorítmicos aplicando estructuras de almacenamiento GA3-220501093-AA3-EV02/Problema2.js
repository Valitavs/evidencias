/*Desarrollar un programa que permita almacenar las edades de un grupo de 10 personas en un vector de
enteros y luego determine la cantidad de personas que son menores de edad, mayores de edad, cuántos
adultos mayores, la edad más baja, la edad más alta y el promedio de edades ingresadas. Para el ejercicio
anterior suponga que un adulto mayor debe tener una edad igual o superior a 60. Debe validar para cada
ingreso que los valores estén en un rango entre 1 y 120 años. En caso de error deberá notificar y solicitar
un nuevo valor*/

let personas =  []

for(let i=0; i<=9; i++){
    personas[i] = prompt(`Ingrese la edad de la persona #${i+1}`)
    personas[i] = parseInt(personas[i])
    while(personas[i]<1 || personas[i]>120){
        personas[i] = prompt(`Se sale del rango, itente de nuevo\nIngrese la edad de la persona #${i+1}`)
        personas[i] = parseInt(personas[i]) 
    }
}
console.log(personas)

function menoresDeEdad(array,array1){
    for(let i=0; i<=9; i++){
        if(array[i]<18){
            let x = array[i]
            array1.push(x)
        }
    }
    console.log("Cantidad de personas menores de edad: ", array1.length)
}

function mayoresDeEdad(array,array1){
    for(let i=0; i<=9; i++){
        if(array[i]>=18){
            let x = array[i]
            array1.push(x)
        }
    }
    console.log("Cantidad de personas mayores de edad: ", array1.length)
}

function adultosMayores(array,array1){
    for(let i=0; i<=9; i++){
        if(array[i]>=60){
            let x = array[i]
            array1.push(x)
        }
    }
    console.log("Cantidad de adultos mayores: ", array1.length)
}

function edadBaja(array){
    let menor = array[0]
    let numeroActual
    for(let i=1; i<=9; i++){
        numeroActual = array[i]
        if(numeroActual<menor){
            menor = numeroActual
        }
    }
    console.log("La edad mas baja es ",menor)
}

function edadAlta(array){
    let mayor = array[0]
    let numeroActual
    for(let i=1; i<=9; i++){
        numeroActual = array[i]
        if(numeroActual>mayor){
            mayor = numeroActual
        }
    }
    console.log("La edad mas alta es ",mayor)
}

function promedio(array){
    let suma = 0
    for(let i=0; i<=9; i++){
    suma = suma + array[i]
    }
    let promedio = suma/10
    console.log("El promedio de las edades es: ",promedio)
}

let menores = []
menoresDeEdad(personas,menores)
let mayores = []
mayoresDeEdad(personas,mayores)
let amayores = []
adultosMayores(personas,amayores)

edadBaja(personas)
edadAlta(personas)
promedio(personas)
