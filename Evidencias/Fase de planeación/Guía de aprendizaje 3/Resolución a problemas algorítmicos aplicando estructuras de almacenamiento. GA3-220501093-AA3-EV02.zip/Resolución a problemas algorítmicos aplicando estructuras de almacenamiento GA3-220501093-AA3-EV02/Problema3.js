/*Escriba un programa que lea dos vectores de números enteros ordenados ascendentemente y luego
produzca la lista ordenada de la mezcla de los dos, por ejemplo, si los dos arreglos tienen los números 1
3 6 9 17 y 2 4 10 17, respectivamente, la lista de números en la pantalla debe ser 1 2 3 4 6 9 10 17 17.
Limite los vectores a un tamaño de 5 y debe validar en cada ingreso que realmente se estén ingresando
los datos de forma ascendente.*/

let vector1 = []
let vector2 = []

for(let i = 0; i <= 4; i++){
    vector1[i] =  prompt(`Vector 1\nIngrese numero del primer vector en posición #${i+1}`)
    vector1[i] =  parseInt(vector1[i])
    while(vector1[i]<=vector1[i-1]){
        vector1[i] =  prompt("El numero que ingreso no sigue el orden ascendente, intente de nuevo")
        vector1[i] =  Number(vector1[i])
    }
}

console.log(vector1)

for(let i = 0; i <= 4; i++){
    vector2[i] =  prompt(`Vector 2\nIngrese numero del segundo vector en posición #${i+1}`)
    vector2[i] =  parseInt(vector2[i])
    while(vector2[i]<=vector2[i-1]){
        vector2[i] =  prompt("El numero que ingreso no sigue el orden ascendente, intente de nuevo")
        vector2[i] =  Number(vector2[i])
    }
}
console.log(vector2)

const VectorDef = vector1.concat(vector2)
VectorDef.sort(function(a, b){return a - b})
console.log(VectorDef)