/*Una emisora con presencia en diferentes ciudades desea conocer el rating de canciones y cantantes más
escuchados (sonados) en este semestre del año. Por lo tanto, se ha pedido a estudiantes del SENA del
programa de tecnólogo en análisis y desarrollo de software desarrollar una solución que permita conocer
la respuesta de 6 personas con relación a sus gustos musicales. Con fines administrativos y realizar una
rifa entre las personas encuestadas, la emisora desea poder registrar de las personas entrevistadas su
nombre, número de identificación (cédula), fecha de nacimiento, correo electrónico, ciudad de residencia,
ciudad de origen. Además, se deberá poder almacenar el artista y título de hasta 3 canciones favoritas en
cada una de las personas que se ingrese, teniendo en cuenta lo anterior, se sugiere que la solución deberá
mostrar un menú que permite las siguientes opciones:
a. Agregar una persona con los datos que se listan anteriormente.
b. Mostrar la información personal de una persona particular por medio de su posición en el vector*/

let personas = []
let info = []

function Agregar(personas,info){
    
    let canciones = []
    let fecha = []

    let nombre =  prompt("Ingrese su nombre")
    let id =  prompt("Ingrese su número de identificación")
    let dia = prompt("Ingrese dia de nacimiento")
    let mes = prompt("Ingrese mes de naciomiento")
    let año = prompt("Ingrese año de nacimiento")
    fecha = [`${dia}/${mes}/${año}`]
    let correo = prompt("Ingrese correo electronico")
    let ciudadr = prompt("Ingrese ciudad de residencia")
    let ciudado = prompt("Ingrese ciudad de origen")
    let artista = prompt("Ingrese artista favorito")

    for(let i=0; i<=2; i++){
        canciones[i] =  prompt(`Canciones favoritas\nIngrese título de canción favorita #${i+1}`)
    }

    info = [`Nombre: ${nombre}`,
            `Identidicación: ${id}`,
            `Fecha de nacimiento: ${fecha}`,
            `Correo electronico: ${correo}`,
            `Ciudad de residencia: ${ciudadr}`,
            `Ciudad de origen: ${ciudado}`,
            `Artista favorito: ${artista}`,
            `Canciones favoritas: ${canciones}`]

    personas.push(info)
    //console.log(personas) 
}

function Mostrar(personas,info){

    let per = prompt(`Hay ${personas.length} personas registradas\n¿Que registro quiere ver?`,"Ingrese numero")
    per = per-1
    if(per>personas.length){
        alert("No existe registro")
    }else{
        console.log(`Registro #${per+1}`)
        personas[per].forEach(element => console.log(element));
    }
}

let n = 0

do{
    let valor = prompt("1. Agregar una persona \n2. Mostrar la información de una persona")
    switch (true){
        case valor == 1:
                n++
                if(n > 6){
                    alert("Se llego al limite de registros")
                }else{
                    Agregar(personas,info)
                } 
        break
        case valor == 2:
                Mostrar(personas,info)
        break
        default:
            console.log("El valor ingresado no es una opción")
    } 
valor1 =  prompt("1 si quiere volver al menu principal")
}while(valor1 == "1")